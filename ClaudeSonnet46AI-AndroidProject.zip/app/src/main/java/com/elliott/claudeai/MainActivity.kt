package com.elliott.claudeai

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var progress: ProgressBar
    private val executor = Executors.newSingleThreadExecutor()
    private val messages = JSONArray()
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chat = findViewById(R.id.chat)
        input = findViewById(R.id.input)
        send = findViewById(R.id.send)
        progress = findViewById(R.id.progress)

        findViewById<Button>(R.id.settingsButton).setOnClickListener { showApiKeyDialog() }
        send.setOnClickListener { sendMessage() }

        if (prefs.getString("api_key", "").isNullOrBlank()) showApiKeyDialog()
    }

    private fun showApiKeyDialog() {
        val box = EditText(this)
        box.hint = "sk-ant-..."
        box.setText(prefs.getString("api_key", ""))
        box.inputType = 129

        AlertDialog.Builder(this)
            .setTitle("Anthropic API key")
            .setMessage("Your key is stored locally on this phone and sent directly to Anthropic.")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("api_key", box.text.toString().trim()).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendMessage() {
        val key = prefs.getString("api_key", "") ?: ""
        val text = input.text.toString().trim()
        if (key.isBlank()) { showApiKeyDialog(); return }
        if (text.isBlank()) return

        input.setText("")
        append("You", text)
        messages.put(JSONObject().put("role", "user").put("content", text))

        send.isEnabled = false
        progress.visibility = View.VISIBLE

        executor.execute {
            try {
                val reply = callClaude(key)
                messages.put(JSONObject().put("role", "assistant").put("content", reply))
                runOnUiThread {
                    append("Claude", reply)
                    send.isEnabled = true
                    progress.visibility = View.GONE
                }
            } catch (e: Exception) {
                runOnUiThread {
                    append("Error", e.message ?: "Request failed")
                    send.isEnabled = true
                    progress.visibility = View.GONE
                }
            }
        }
    }

    private fun callClaude(key: String): String {
        val url = URL("https://api.anthropic.com/v1/messages")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.doOutput = true

        val body = JSONObject()
            .put("model", "claude-sonnet-4-6")
            .put("max_tokens", 4096)
            .put("messages", messages)

        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("HTTP $code: $response")

        val json = JSONObject(response)
        val content = json.getJSONArray("content")
        val out = StringBuilder()
        for (i in 0 until content.length()) {
            val item = content.getJSONObject(i)
            if (item.optString("type") == "text") out.append(item.optString("text"))
        }
        return out.toString().ifBlank { "Claude returned an empty response." }
    }

    private fun append(who: String, text: String) {
        chat.append("\n\n$who:\n$text")
        chat.post { findViewById<ScrollView>(R.id.scroll).fullScroll(View.FOCUS_DOWN) }
    }
}
