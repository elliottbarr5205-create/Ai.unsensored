# Claude Sonnet 4.6 AI for Android

This is a native Android chat app using Anthropic's Messages API and model `claude-sonnet-4-6`.

## Important
The APK intentionally does NOT contain an API key. Enter your own Anthropic API key in the app.

## Build
Open this project in Android Studio and build `app > assembleDebug`, or push it to GitHub and run the included Actions workflow.

Anthropic's official documentation confirms the Sonnet 4.6 API model ID is `claude-sonnet-4-6`.
